package com.example.kongstore

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
